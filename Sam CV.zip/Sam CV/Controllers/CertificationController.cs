﻿using Microsoft.AspNetCore.Mvc;

namespace Sam_CV.Controllers
{
    public class CertificationController : Controller
    {
        public IActionResult Certi()
        {
            return View();
        }
    }
}
