﻿using Microsoft.AspNetCore.Mvc;

namespace Sam_CV.Controllers
{
    public class SkillsController : Controller
    {
        public IActionResult Skill()
        {
            return View();
        }
    }
}
