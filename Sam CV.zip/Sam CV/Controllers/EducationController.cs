﻿using Microsoft.AspNetCore.Mvc;

namespace Sam_CV.Controllers
{
    public class EducationController : Controller
    {
        public IActionResult Edu()
        {
            return View();
        }
    }
}
